export default function Multiplication(x){
    return (
        <div>
            Multiplication : {x.nums[0] * x.nums[1]} 
        </div>
    )
}