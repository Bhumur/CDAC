export default function Addition({nums}){
    return (
        <div>
            Addition : {nums[0] + nums[1]} 
        </div>
    )
}