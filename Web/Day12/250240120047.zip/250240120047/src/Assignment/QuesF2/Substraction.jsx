export default function Substraction(x){
    return (
        <div>
            Substraction : {x.nums[0] - x.nums[1]} 
        </div>
    )
}