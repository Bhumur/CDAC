import A from "./A";
import B from "./B";
import C from "./C";

export default function QuesF1C_Main(){
    return (
        <>
            <A/>
            <B/>
            <C/>
        </>
    )
}