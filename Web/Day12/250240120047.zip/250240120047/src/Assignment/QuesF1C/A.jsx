export default function A(){
    return(
        <div>
            This is A component
        </div>
    )
}