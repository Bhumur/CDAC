import A from "./A";
import B from "./B";

export default function C(){
    return(
        <div>
            This is C component
            <A/>
            <B/>
        </div>
    )
}