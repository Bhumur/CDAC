import B from "./B";
import C from "./C";

export default function QuesF1D_Main(){
    return (
        <>
            <B/>
            <C/>
        </>
    )
}