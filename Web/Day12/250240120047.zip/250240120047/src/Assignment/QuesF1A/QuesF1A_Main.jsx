import A from "./A";

export default function QuesF1A_Main(){
    return (
        <>
            <A/>
        </>
    )
}