import C from "./C";

export default function B(){
    return(
        <div>
            This is B component
            <C/>
        </div>
    )
}