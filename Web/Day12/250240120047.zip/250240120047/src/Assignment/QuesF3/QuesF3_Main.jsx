import Fruit from "./Fruit";

export default function QuesF3_Main(){
    return  <>
                <Fruit />
            </>
}